# Production du projet *66B-modele_de_projet*
C'est ici qu'on dépose les fichiers et dossiers de la production. 

Dans le dossier **docs**, on retrouve:
* La préproduction du projet à réaliser en début de projet;
* Les journaux de création individuels de chaque membre de l'équipe à remplir chaque semaine;
* Votre page Web d'équipe à mettre à jour chaque semaine.
