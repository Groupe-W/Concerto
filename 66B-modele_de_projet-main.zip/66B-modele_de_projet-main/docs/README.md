# Dossier de documentation du projet *66B-modele_de_projet*

Dans ce dossier, on retrouve:

* La préproduction du projet à réaliser en début de projet;
* Les journaux de création individuels de chaque membre de l'équipe à remplir chaque semaine;
* Votre page Web d'équipe à mettre à jour chaque semaine (**index.html**).
