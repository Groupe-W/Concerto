# Expérience / Interface de diffusion
Vous créez ici votre page Web où est vécue l'expérience de votre projet. Elle correspond à l'interface avec laquelle l'utilisateur-trice interagit.